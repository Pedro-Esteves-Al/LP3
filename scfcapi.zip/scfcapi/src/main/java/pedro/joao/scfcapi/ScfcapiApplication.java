package pedro.joao.scfcapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScfcapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScfcapiApplication.class, args);
	}

}
